# FrigoTrack – Telemetria sicura per la catena del freddo

Sistema client-server **HTTP** (niente HTTPS) in C# / .NET 8: i sensori inviano misure JSON
**cifrate con AES-256-GCM** usando una chiave concordata con **Diffie-Hellman** (RFC 3526, gruppo 14),
e ogni messaggio è validato con **JSON Schema** (draft 2020-12).

## Struttura

| Cartella | Contenuto |
|---|---|
| `schemas/` | un file JSON Schema per ogni tipo di messaggio |
| `FrigoTrack.Common` | Diffie-Hellman, AES-GCM, validazione schemi, client del protocollo |
| `FrigoTrack.Server` | server ASP.NET Core (minimal API) su `http://localhost:5000` |
| `FrigoTrack.Client` | app console che simula 3 sensori |
| `FrigoTrack.Tests` | test xUnit (6) |

## Avvio (Visual Studio 2022)

1. Apri `FrigoTrack.sln`; Visual Studio ripristina i pacchetti NuGet da solo.
2. Tasto destro sulla soluzione → **Configura progetti di avvio** → *Più progetti*:
   `FrigoTrack.Server` = **Avvia**, `FrigoTrack.Client` = **Avvia** (Server sopra al Client). Poi **F5**.

Da terminale, in due finestre:

```
dotnet run --project FrigoTrack.Server
dotnet run --project FrigoTrack.Client            # aggiungi  --invalid  per la demo del messaggio errato
dotnet test
```

Le misure vengono salvate in `FrigoTrack.Server/bin/Debug/net8.0/data/readings.json`.

## Handshake (diagramma di sequenza)

```mermaid
sequenceDiagram
    participant C as Client (sensore)
    participant S as Server
    Note over C: sceglie a casuale<br/>A = g^a mod p
    C->>S: POST /api/handshake {p, g, A} (in chiaro)
    Note over S: sceglie b casuale<br/>B = g^b mod p<br/>K = A^b mod p<br/>genera session_id
    S-->>C: 200 {session_id, B}
    Note over C: K = B^a mod p<br/>(stesso K del server)
    Note over C,S: chiave = SHA-256(K) — K non viaggia mai in rete
    C->>S: POST /api/telemetry {session_id, ciphertext, tag}
    Note over S: 1. decifra (tag GCM)<br/>2. valida con lo schema<br/>3. salva, controlla allarme
    S-->>C: 200 busta cifrata {status, alarm?}
    C->>S: POST /api/close (busta cifrata)
    S-->>C: 200 busta cifrata, poi la chiave viene cancellata
```

## Messaggi

| Endpoint | Schema richiesta | Schema risposta |
|---|---|---|
| `/api/handshake` | `handshake-request` (in chiaro) | `handshake-response` (in chiaro) |
| `/api/telemetry` | `telemetry-request` | `telemetry-response` |
| `/api/readings` | `readings-request` | `readings-response` |
| `/api/close` | `close-request` | `close-response` |
| qualsiasi errore | — | `error` |

Tutto ciò che non è l'handshake viaggia nella busta `envelope`: `session_id` (in chiaro), `ciphertext` e `tag` in Base64.
Il `ciphertext` contiene `nonce (12 byte) + dati cifrati`.

## Codici HTTP

| Codice | Quando |
|---|---|
| 200 | tutto ok |
| 400 | JSON/busta malformati, decifratura o tag falliti, messaggio non conforme allo schema (con il campo sbagliato in `details`) |
| 401 | `session_id` inesistente o sessione chiusa |
| 404 | endpoint inesistente, oppure sensore senza misure in `/api/readings` |

## Allarmi

Pharma 2–8 °C, food 0–5 °C, frozen −30…−18 °C. Fuori intervallo la risposta contiene `alarm`.

## Limiti noti

- Nessuna protezione da *replay*: una busta valida catturata può essere rinviata.
- DH senza autenticazione: un attaccante attivo (man-in-the-middle) potrebbe fare handshake con entrambi.
- Gli errori 400/401 prodotti *prima* di avere la chiave sono in chiaro (ma generici).
- Sessioni e chiavi solo in memoria (persi al riavvio), nessuna scadenza automatica.
- Misure salvate in un unico file JSON riscritto a ogni invio: va bene per un prototipo, non per migliaia di sensori.
- La chiave AES è SHA-256(K) senza HKDF; il `session_id` è di soli 32 bit.
